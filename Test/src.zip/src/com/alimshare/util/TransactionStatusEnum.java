package com.alimshare.util;

public enum TransactionStatusEnum {
	SUCCESS, FAIL, PENDING, REVERSAL
}
