package com.alimshare.util;

public enum DestinationTypeEnum {
	SAVING, GIRO, LOAN
}
