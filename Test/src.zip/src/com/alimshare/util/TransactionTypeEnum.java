package com.alimshare.util;

public enum TransactionTypeEnum {
	ANTAR_ACCOUNT, ANTAR_BANK_LOCAL, ANTAR_BANK_INTERNATIONAL
}
