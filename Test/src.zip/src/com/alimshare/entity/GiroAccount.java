package com.alimshare.entity;

public class GiroAccount extends Account {

}
