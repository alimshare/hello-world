package com.alimshare.entity;

public class LoanAccount extends Account {

}
