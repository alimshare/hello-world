package com.alimshare.entity;

public class SavingAccount extends Account {

}
