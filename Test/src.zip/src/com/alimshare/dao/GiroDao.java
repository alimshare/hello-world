package com.alimshare.dao;

public class GiroDao extends AccountDao {

}
