package com.alimshare.dao;

public class SavingDao extends AccountDao{

}
