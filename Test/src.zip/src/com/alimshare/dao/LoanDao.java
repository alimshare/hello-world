package com.alimshare.dao;

public class LoanDao extends AccountDao {

}
